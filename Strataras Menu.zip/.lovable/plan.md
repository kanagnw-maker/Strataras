## Στόχος
Το κουμπί «Διάβασε» του Στρατάρα να λειτουργεί και για επισκέπτες στο public site/custom domain.

## Διάγνωση
Το `/api/tts` δέχεται κλήσεις από το κουμπί, αλλά στα server logs επιστρέφει `403` για το custom domain `paratairon.sipoflesvos.com`. Ο έλεγχος origin επιτρέπει μόνο localhost, lovable.app και lovableproject.com, άρα μπλοκάρει τους επισκέπτες στο κανονικό domain.

## Πλάνο αλλαγής
1. Ενημέρωση του origin allowlist στο `src/routes/api/tts.ts` ώστε να επιτρέπει και το `paratairon.sipoflesvos.com`.
2. Να εφαρμοστεί η ίδια διόρθωση και στους δύο handlers του TTS (`GET` για το κουμπί επισκέπτη και `POST` για δοκιμή/admin), χωρίς να αλλάξει η φωνή ή η λογική του ElevenLabs.
3. Να γίνει μικρό refactor σε κοινή helper συνάρτηση για τον origin check, ώστε να μη ξαναχαλάσει σε ένα από τα δύο endpoints.
4. Έλεγχος με server request ότι το `/api/tts?...` δεν επιστρέφει πλέον `403` από το public domain.

## Τεχνικές λεπτομέρειες
- Δεν χρειάζεται αλλαγή στη βάση.
- Δεν χρειάζεται αλλαγή στο Voice ID.
- Το πρόβλημα είναι access/origin filtering, όχι το κουμπί ή το ElevenLabs.